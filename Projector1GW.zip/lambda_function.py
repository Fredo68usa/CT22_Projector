import json
from elasticsearch import Elasticsearch, helpers
import configparser
import boto3
import gzip
from io import BytesIO
import urllib
from datetime import date

client = boto3.client("s3")

def lambda_handler(event, context):

    # Go get the file that was added to S3
    obj = client.get_object(
        Bucket = event['Records'][0]['s3']['bucket']['name'],
        Key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key']),
           )


    # gunzip the file       
    z = gzip.decompress(obj['Body'].read())

    # =======================
    #    write into Elastic
    # =======================
    es = Elasticsearch(
        cloud_id="",
        http_auth=("elastic", "")
        )

    # =======
    # record
    # =======
    today=date.today()
    year = today.year
    month = today.month
    day = today.day
 
    ind =  es.index(
        index='audit_s3_dyn_'+str(year)+str(month)+str(day),
        document=z
       )


    return {
        'statusCode': 200,
    }

